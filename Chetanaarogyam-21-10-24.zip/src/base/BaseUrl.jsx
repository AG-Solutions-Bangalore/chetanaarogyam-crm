
const BASE_URL = "https://chetanaarogyam.com/public";



export default BASE_URL;
